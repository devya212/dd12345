package com.nucleus.csrfsecurity;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Mukesh Dewangan
 * @since 03 December 2018
 * This filter will help us to add csrf token in the user login and registration form and validate it while logging in and registration process.
 */
public class CustomAuthenticationCsrfFilter implements Filter
{

	@Override
	public void destroy() {
		//Does not need to initialize anything.
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		if (!((HttpServletRequest)request).getMethod().equalsIgnoreCase("POST") ) {
			// Not a POST - allow the request
			chain.doFilter(request, response);
		} else {
			// This is a POST request - need to check the CSRF token
			String sessionToken = CSRFTokenManager.getTokenForSession(((HttpServletRequest) request).getSession());
			String requestToken = CSRFTokenManager.getTokenFromRequest((HttpServletRequest) request);
			if (sessionToken.equals(requestToken)) {
				chain.doFilter(request, response);
			} else {
				((HttpServletResponse) response).sendError(HttpServletResponse.SC_FORBIDDEN, "Bad or missing CSRF value");
			}
		}
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		//Does not need to initialize anything.
	}

}
