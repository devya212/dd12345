package com.nucleus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.FAQ;
import com.nucleus.service.FAQService;

@Controller
public class FAQController {
	
	@Autowired
	FAQService faqService;
	
	
	@RequestMapping(value="/viewFAQ")
	public ModelAndView viewFAQ(@RequestParam(value="searchString",required=false)String searchString)
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("FAQ/viewFAQ");
		
		if (searchString == null || searchString.equals(""))
			mv.addObject("AllFAQ", faqService.getAllFAQ());
		else
			{
				mv.addObject("AllFAQ", faqService.getFilteredFAQ(searchString));
				mv.addObject("searchString", searchString);
			}
		return mv;
	}
	
	@RequestMapping("/openFAQForm")
	public String openFAQForm(FAQ faq)
	{
		return "FAQ/submitFAQForm";
	}
	
	@RequestMapping(value="/saveFAQ", method=RequestMethod.POST)
	public ModelAndView saveFAQ(@RequestParam("question")String question, @RequestParam("answer")String answer)
	{
		ModelAndView mv = new ModelAndView();
		faqService.saveFAQ(new FAQ(question, answer));
		mv.setViewName("redirect:/viewFAQ");
		return mv;
	}
	
	
//	@RequestMapping(value="/searchFAQ", method=RequestMethod.POST)
//	public ModelAndView searchFAQ(@RequestParam("searchString")String searchString)
//	{
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("FAQ/viewFAQ");
//		mv.addObject("AllFAQ", faqService.getFilteredFAQ(searchString));
//		return mv;
//	}
	

}
