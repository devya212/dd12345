package com.nucleus.controller;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nucleus.dao.DiscussionForumDao;
import com.nucleus.pojo.DiscussionPost;
import com.nucleus.pojo.DiscussionThread;
import com.nucleus.pojo.DiscussionThreadCategory;
import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.service.DiscussionForumService;
import com.nucleus.service.UserService;
import com.nucleus.utility.DiscussionForumThreadListView;
import com.nucleus.utility.PFinnPostUpdate;
import com.nucleus.utility.ResponseMessage;
import com.nucleus.utility.ResponseMessage.ResponseMessageStatus;
import com.nucleus.utility.SearchParameterOperation;

@Controller
public class DiscussionForumController 
{
	
	static final String ERROR_MESSAGE = "Oops!! Something went wrong.";
	static final String UNIQUE_CONSTRAINT_VIOLATION_CODE = "UniqueConstraintViolation";
	static final String RESPONSE_PARAMETER = "response";

	static final String PARENT_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT = "discussionThreadCategoryParentCreationModelBindingResult";
	static final String PARENT_THREAD_CATEGORY_UPDATION_MODEL_NAME = "discussionThreadCategoryParentUpdationModel";
	static final String PARENT_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT = "discussionThreadCategoryParentUpdationModelBindingResult";

	static final String SUB_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT = "discussionThreadCategorySubCategoryCreationModelBindingResult";
	static final String SUB_THREAD_CATEGORY_UPDATION_MODEL_NAME = "discussionThreadCategorySubCategoryUpdationModel";
	static final String SUB_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT = "discussionThreadCategorySubCategoryUpdationModelBindingResult";
	
	static final String DISCUSSION_FORUM_HOME_REDIRECTION = "redirect:/forum/";
	static final String DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION = "redirect:/forum/discussionForumCategories";
	
	
	@Autowired
	DiscussionForumService discussionForumService;

	@Autowired 
	UserService userService;
	
	private int startingPage = 1;
	private String startingThreadListingType = "Latest";
	private int standardPerPageRecord = 10;
	
	@Autowired
	DiscussionForumDao discussionForumDao;
	
	@RequestMapping("/test")
	public void test()
	{
		System.out.println(discussionForumDao.test());
	}
	
	/**
	 * @author Ajita Mittal
	 * @since 24 September 2018
	 * It will display the landing page of forum
	 */
	@RequestMapping(value="/forum")
	public ModelAndView index(DiscussionThread discussionThread)
	{
		ModelAndView modelAndView = new ModelAndView("DiscussionForum/index");
		modelAndView.addObject("currentThreadsListingType", startingThreadListingType);
		modelAndView.addObject("currentPage", startingPage);
		modelAndView.addObject("currentCategory", "");
		
		modelAndView.addObject("discussionThreadModel", discussionThread);	
		
		modelAndView.addObject("categories", discussionForumService.getCategories(-1));
		modelAndView.addObject("allCategories", discussionForumService.getCategories(-2));

		return modelAndView;
	}
	
	
	/**
	 * @author Ajita Mittal
	 * @since 24 September 2018
	 * It will display the index page for any particular category name
	 */
	@RequestMapping(value="/forum/{categoryName:.+}")
	public ModelAndView getSubCategory(@PathVariable("categoryName") String categoryName)
	{
		DiscussionThreadCategory currentDiscussionThreadCategory = discussionForumService.fetchByCategoryName(categoryName);

		if(currentDiscussionThreadCategory != null)
		{
			ModelAndView modelAndView = new ModelAndView("DiscussionForum/index");
			modelAndView.addObject("currentThreadsListingType", startingThreadListingType);
			modelAndView.addObject("currentPage", startingPage);
			modelAndView.addObject("currentCategory", currentDiscussionThreadCategory);
			
			modelAndView.addObject("discussionThreadModel",new DiscussionThread());
			
			modelAndView.addObject("allCategories",discussionForumService.getCategories(-2));
			modelAndView.addObject("currentCategoryID", currentDiscussionThreadCategory.getCategoryId());
			
			modelAndView.addObject("categories", discussionForumService.getCategories(currentDiscussionThreadCategory.getCategoryId()));
			return modelAndView;
		}
		else
		{
			return new ModelAndView("redirect:/404");
		}
	}
	

	/**
	 * @author Vasu
	 * @since 24 September 2018
	 * @param 	1> Model attribute - discussionThreadCategory (DiscussionThreadCategory)
	 * @return It will return discussion forum categories
	 */
	@RequestMapping("/forum/discussionForumCategories")
	public ModelAndView discussionForumCategories(@ModelAttribute("discussionThreadCategoryParentCreationModel") DiscussionThreadCategory discussionThreadCategoryParentModel, 
			@ModelAttribute("discussionThreadCategorySubCategoryCreationModel") DiscussionThreadCategory discussionThreadCategorySubCategoryCreationModel, 
			@ModelAttribute(PARENT_THREAD_CATEGORY_UPDATION_MODEL_NAME) DiscussionThreadCategory discussionThreadCategoryParentUpdationModel,
			@ModelAttribute(SUB_THREAD_CATEGORY_UPDATION_MODEL_NAME) DiscussionThreadCategory discussionThreadCategorySubCategoryUpdationModel, 
			Model model) 
	{
		ModelAndView modelAndView = new ModelAndView("DiscussionForum/discussion-forum-categories");
		modelAndView.addObject("categories",discussionForumService.getCategories(-2));
		
		modelAndView.addObject("discussionThreadCategoryParentCreationModel", discussionThreadCategoryParentModel);
		if(model.asMap().containsKey(PARENT_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT))
			modelAndView.addObject("org.springframework.validation.BindingResult.discussionThreadCategoryParentCreationModel", model.asMap().get(PARENT_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT));

		modelAndView.addObject("discussionThreadCategorySubCategoryCreationModel", discussionThreadCategorySubCategoryCreationModel);
		if(model.asMap().containsKey(SUB_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT))
			modelAndView.addObject("org.springframework.validation.BindingResult.discussionThreadCategorySubCategoryCreationModel", model.asMap().get(SUB_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT));

		modelAndView.addObject(PARENT_THREAD_CATEGORY_UPDATION_MODEL_NAME, discussionThreadCategoryParentUpdationModel);
		if(model.asMap().containsKey(PARENT_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT))
			modelAndView.addObject("org.springframework.validation.BindingResult.discussionThreadCategoryParentUpdationModel", model.asMap().get(PARENT_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT));

		modelAndView.addObject(SUB_THREAD_CATEGORY_UPDATION_MODEL_NAME, discussionThreadCategorySubCategoryUpdationModel);
		if(model.asMap().containsKey(SUB_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT))
			modelAndView.addObject("org.springframework.validation.BindingResult.discussionThreadCategorySubCategoryUpdationModel", model.asMap().get(SUB_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT));

		return modelAndView;
	}
	

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> Request parameter- page (String)
	 * 			2> Request parameter- threadsListingType (String)
	 * 			3> Request parameter- categoryName (String)
	 * @return It will return the list of threads according to page-no., thread-listing-type and category-name
	 */
	@RequestMapping(value="/forum/getDiscussionsThreads", method=RequestMethod.POST)
	public ModelAndView getMoreDiscussionsThreads(@RequestParam("page") String page,
								@RequestParam("threadsListingType") String threadsListingType,
								@RequestParam("categoryName") String categoryName)
	{
		ModelAndView modelAndView = new ModelAndView("DiscussionForum/ThreadList");
		int pageNo = startingPage;
		if(page != null && !"".equals(page))
			pageNo = Integer.parseInt(page);
		int perPageRecord = standardPerPageRecord;
		modelAndView.addObject("discussionThreads", discussionForumService.getDiscussionThreads(categoryName, threadsListingType, pageNo, perPageRecord));
		return modelAndView;
	}
	
	
	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> Path variable- thread (String)
	 * 			2> Optional Request parameter- page (String)
	 * 			3> DiscussionPost - Model Attribute
	 * 			4> DiscussionThread - Model Attribute
	 * @return It will display the single thread and all of its post
	 */
	@RequestMapping(value="/forum/{categoryName:.+}/{thread}", method=RequestMethod.GET)
	public ModelAndView showThread(@PathVariable("thread") String thread, @RequestParam(value="page", required=false) String page, DiscussionPost discussionPost, DiscussionThread discussionThread)
	{
		ModelAndView modelAndView = new ModelAndView();
		int threadId = Integer.parseInt(thread.split("-")[0]);
		DiscussionThread discussionThreadObject = discussionForumService.getDiscussionThreadByThreadId(threadId);
		if(discussionThreadObject != null)
		{
			if(discussionThreadObject.getThreadStatus() != null)
			{
				
				Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
				if (!(authentication instanceof AnonymousAuthenticationToken)) 
				{
					PFinnNewUser user = userService.getUserByUserName(authentication.getName());
					discussionForumService.checkIfUserHasViewedThisThread(user, discussionThreadObject);
				}
				
				
				int pageNo = 1;
				if(page != null && !"".equals(page))
					pageNo = Integer.parseInt(page);
				int perPageRecord = 20;
				int totalNoOfApprovedPost = discussionForumService.getApprovedDeletedPostsOfThread(discussionThreadObject, 0, 0).size();
				int totalNoOfPages = (int)Math.ceil((double)totalNoOfApprovedPost / perPageRecord);
				totalNoOfPages = (totalNoOfPages == 0)? 1 : totalNoOfPages;
				
				List<DiscussionPost> discussionPosts = discussionForumService.getApprovedDeletedPostsOfThread(discussionThreadObject, pageNo, perPageRecord);
				
				modelAndView.setViewName("DiscussionForum/ThreadView");
				modelAndView.addObject("discussionPostModel", discussionPost);
				modelAndView.addObject("discussionThreadObject", discussionThreadObject);
				modelAndView.addObject("discussionPosts", discussionPosts);
		    	modelAndView.addObject("totalNoOfApprovedPost", totalNoOfApprovedPost);
		    	modelAndView.addObject("currentPage", pageNo);
		    	modelAndView.addObject("totalNoOfPages", totalNoOfPages);
		    	modelAndView.addObject("perPageRecord", perPageRecord);
		    	
		    	if(discussionThread.getDiscussionThreadId() == 0)
		    	{
		    		discussionThread = discussionForumService.getDiscussionThreadByThreadId(threadId);
		    	}
		    	
				modelAndView.addObject("discussionThreadModel", discussionThread);
		    	modelAndView.addObject("allCategories",discussionForumService.getCategories(-2));
			}
			else
				modelAndView.setViewName("redirect:/");
		}
		else
			modelAndView.setViewName("redirect:/404");
		
		return modelAndView;
	}
	
	
	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> Path variable- categoryId (String)
	 * 			2> Path variable- thread (String)
	 * 			3> Request parameter- discussionPost (DiscussionPost)
	 * 			4> Request parameter- totalNoOfPages (String)
	 * @return It will store the post for particular thread in database and redirect to that thread.
	 */
	@RequestMapping(value="/forum/{categoryName:.+}/{thread}", method=RequestMethod.POST)
	public String postCommentOnThread(@PathVariable("categoryName") String categoryId, @PathVariable String thread, @ModelAttribute("discussionPostModel") @Valid DiscussionPost discussionPost, BindingResult bindingResult, @RequestParam("totalNoOfPages") String noOfPages, RedirectAttributes redirectAttributes)
	{	
		int threadId = Integer.parseInt(thread.split("-")[0]);
		int totalNoOfPages = Integer.parseInt(noOfPages);
		
		if (bindingResult.hasErrors() && bindingResult.hasFieldErrors("postContent")) 
		{
			redirectAttributes.addFlashAttribute("discussionPost", discussionPost);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.discussionPostModel", bindingResult);
			return DISCUSSION_FORUM_HOME_REDIRECTION+categoryId+"/"+thread+"?page="+totalNoOfPages;
		}
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (!(authentication instanceof AnonymousAuthenticationToken)) 
		{
			discussionPost.setPostedByUser(userService.getUserByUserName(authentication.getName()));
			
			boolean isAdmin = false;
			
			@SuppressWarnings("unchecked")
			Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) authentication.getAuthorities();
			for(GrantedAuthority authority:authorities)
			{
				if(authority.getAuthority().equalsIgnoreCase("ROLE_ADMIN"))
				{
					isAdmin = true;
					break;
				}
			}
			
			if(isAdmin)
			{
				discussionPost.setStatus("APPROVED");
				discussionPost.setStatusTime(new Date(System.currentTimeMillis()));
			}
			
			ResponseMessage responseMessage = null;

			try
			{
				discussionForumService.postCommentOnThread(discussionPost, threadId);
				if(isAdmin)
					responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully posted.");
				else
					responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully posted and it has gone for approval.");
			}
			catch (Exception e) 
			{
				responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
			}
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
			
			return DISCUSSION_FORUM_HOME_REDIRECTION+categoryId+"/"+thread+"?page="+totalNoOfPages;
		}
		return "redirect:/";
	}
	

	/**
	 * @author Ajita Mittal
	 * @since 23 November 2018
	 * @param Request Parameter - searchString (String)
	 * @return It will return the list of discussion threads according to the searched parameter.
	 * Displaying all the discussion threads according to the searched parameter.
	 */
	@RequestMapping(value="/forum/searchDiscussionsThreads", method=RequestMethod.POST)
	public ModelAndView searchDiscussionsThreads(@RequestParam("searchString") String searchString)
	{
		ModelAndView modelAndView = new ModelAndView("DiscussionForum/ThreadList");
		if(searchString != null && !searchString.equalsIgnoreCase(""))
		{
			List<DiscussionForumThreadListView> discussionForumThreadList = discussionForumService.searchDiscussionThreads(searchString);

			for(DiscussionForumThreadListView discussionThreadListView: discussionForumThreadList)
			{
				discussionThreadListView.getDiscussionThread().setDescription(SearchParameterOperation.changeColorOfSearchedString(discussionThreadListView.getDiscussionThread().getDescription(), searchString));
				discussionThreadListView.getDiscussionThread().setTitle(SearchParameterOperation.changeColorOfSearchedString(discussionThreadListView.getDiscussionThread().getTitle(), searchString));
			}
			
			modelAndView.addObject("discussionThreads", discussionForumThreadList);
		}
		return modelAndView;
	}
	
	
	
	
//	 Admin Work Power

	
	/**
	 * @author Vasu Sharma
	 * @since 24 September 2018
	 * @param  discussionThread object reference with filled data by admin
	 * @return redirect to new Discussion Thread creation form
	 */
	@RequestMapping(value="/forum/Admin/createDiscussionThread", method=RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView createDiscussionThread(@ModelAttribute("discussionThreadModel") @Valid DiscussionThread discussionThread,BindingResult bindingResult, RedirectAttributes redirectAttributes) 
	{
	
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("redirect:/forum");
		
		// current date and time
		discussionThread.setPostedDate(new Date());
		
		// user who posted
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (!(authentication instanceof AnonymousAuthenticationToken))
			discussionThread.setPostedByUser(userService.getUserByUserName(authentication.getName()));
		
		// category(static) 
		// advanced java

		for(DiscussionThreadCategory discussionThreadCategory :discussionForumService.getCategories(-2)){
			if(discussionThreadCategory.getCategoryName().equalsIgnoreCase(discussionThread.getCategory().getCategoryName()))
				discussionThread.setCategory(discussionThreadCategory);
		}
		
		// status of thread (static)
		discussionThread.setThreadStatus("OPEN");
		
		if(discussionThread.getCategory().getCategoryId() == 0)
			bindingResult.rejectValue("category.categoryName", "NotValid", "Select valid thread category.");
		
		if (bindingResult.hasErrors() && (bindingResult.hasFieldErrors("title") || bindingResult.hasFieldErrors("category.categoryName"))) 
		{
			redirectAttributes.addFlashAttribute("discussionThread", discussionThread);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.discussionThreadModel", bindingResult);
			redirectAttributes.addFlashAttribute("modalIdHavingError", "ThreadCreationModal");
			modelAndView.setViewName("redirect:/forum");
			return modelAndView;
		}

		// CREATE
		try
		{
			discussionForumService.createThread(discussionThread);
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully created a thread.");
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		catch (Exception e) 
		{
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		
		
		return modelAndView;
	}
	
	
	
	/**
	 * @author Ajita Mittal
	 * @since 09-oct-2018
	 * @param discussionThread
	 * @param bindingResult
	 * @param redirectAttributes
	 * Updation of already created discussion thread 
	 */
	@RequestMapping(value="/forum/Admin/updateDiscussionThread",  method=RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView updateDiscussionThread(@ModelAttribute("discussionThreadModel") @Valid DiscussionThread discussionThread, BindingResult bindingResult,RedirectAttributes redirectAttributes)
	{	
		ModelAndView modelAndView=new ModelAndView();
		
		for(DiscussionThreadCategory discussionThreadCategory :discussionForumService.getCategories(-2)){
			if(discussionThreadCategory.getCategoryName().equalsIgnoreCase(discussionThread.getCategory().getCategoryName()))
				discussionThread.setCategory(discussionThreadCategory);
		}
		
		DiscussionThread mainDiscussionThread = discussionForumService.getDiscussionThreadByThreadId(discussionThread.getDiscussionThreadId());
		
		modelAndView.setViewName(DISCUSSION_FORUM_HOME_REDIRECTION+mainDiscussionThread.getCategory().getCategoryName()+"/"+mainDiscussionThread.getDiscussionThreadId()+"-"+mainDiscussionThread.getTitle());
		
		DiscussionThreadCategory discussionThreadCategoryForValidation = discussionForumService.fetchByCategoryName(
				discussionThread.getCategory().getCategoryName());
				
		if(discussionThreadCategoryForValidation == null)
			bindingResult.rejectValue("category.categoryName", "NotValid", "Select valid thread category.");
		
		if (bindingResult.hasErrors() && (bindingResult.hasFieldErrors("title") || bindingResult.hasFieldErrors("category.categoryName"))) 
		{
			redirectAttributes.addFlashAttribute("discussionThread", discussionThread);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.discussionThreadModel", bindingResult);
			redirectAttributes.addFlashAttribute("modalIdHavingError", "ThreadUpdationModal");
			return modelAndView;
		}
	
		modelAndView.setViewName(DISCUSSION_FORUM_HOME_REDIRECTION+discussionThread.getCategory().getCategoryName()+"/"+discussionThread.getDiscussionThreadId()+"-"+discussionThread.getTitle());

		try
		{
			discussionForumService.updateThread(discussionThread);
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully updated the thread.");
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		catch (Exception e) 
		{
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		
		return modelAndView;
	}
	
	
	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> Path variable- categoryId (String)
	 * 			2> Path variable- thread (String)
	 * @return It will allow admin to change the status of discussion thread such as OPEN/CLOSE and redirect to that thread.
	 */
	@RequestMapping(value="/forum/Admin/changeThreadStatus/{categoryName:.+}/{thread}", method=RequestMethod.GET)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String changeThreadStatus(@PathVariable("categoryName") String categoryId, @PathVariable("thread") String thread, RedirectAttributes redirectAttributes)
	{
		int threadId = Integer.parseInt(thread.split("-")[0]);
		try
		{
			discussionForumService.changeDiscussionThreadStatus(threadId);
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "Thread status changed successfully.");
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		catch (Exception e) 
		{
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		return DISCUSSION_FORUM_HOME_REDIRECTION+categoryId+"/"+thread;
	}
	
	
	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> Path variable- discussionThreadPostId (String)
	 * 			2> Path variable- categoryId (String)
	 * 			3> Path variable- thread (String)
	 * @return It will allow admin to delete post on any thread and redirect to that thread.
	 */
	@RequestMapping(value="/forum/Admin/deletePost/{postId}/{categoryName:.+}/{thread}", method=RequestMethod.GET)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String deletePost(@PathVariable("postId") String discussionThreadPostId, @PathVariable("categoryName") String categoryId, @PathVariable("thread") String thread, RedirectAttributes redirectAttributes)
	{
		int postId = Integer.parseInt(discussionThreadPostId);
		try
		{
			discussionForumService.deletePost(postId);
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "Post deleted successfully.");
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		catch(Exception e)
		{
			ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
			redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
		}
		return DISCUSSION_FORUM_HOME_REDIRECTION+categoryId+"/"+thread;
	}
	
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 * Displaying all the posts to the admin to update the status
	 */
	@RequestMapping(value="/forum/Admin/viewAllPosts")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView adminViewAll()
	{
		return new ModelAndView("DiscussionForum/discussionFormApproval","pFinnUserThread",new PFinnPostUpdate(discussionForumService.viewAll()));
	}
	
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 * Sending the updated data to the Database after updating the status
	 */
	@RequestMapping(value="/forum/Admin/postUpdate", method=RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String updateAdmin(PFinnPostUpdate pFinnPostUpdate)
	{
		discussionForumService.updatePostStatus(pFinnPostUpdate.getpFinnUserPostList());
		return "redirect:/forum/Admin/viewAllPosts";
	}
	
	
	/**
	 * @author Mukesh Dewangan
	 * @since 10 October 2018
	 * @param 	1> Model Attribute - discussionThreadCategoryParent (DiscussionThreadCategory) 
	 * 			2> Model Attribute - discussionThreadCategorySubCategory (DiscussionThreadCategory) 
	 * @return It will allow admin to create new parent thread category and new sub-category.
	 */
	@RequestMapping("/forum/Admin/createDiscussionThreadCategory")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView createDiscussionThreadCategory(@ModelAttribute("discussionThreadCategoryParentCreationModel") @Valid DiscussionThreadCategory discussionThreadCategoryParent, BindingResult bindingResultParent, 
			@ModelAttribute("discussionThreadCategorySubCategoryCreationModel") @Valid DiscussionThreadCategory discussionThreadCategorySubCategory,BindingResult bindingResultSubCategory,
			RedirectAttributes redirectAttributes) 
	{
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName(DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION);

		//parent
		if (discussionThreadCategoryParent.getParentCategory()==null)
		{
			DiscussionThreadCategory mainParentDiscussionThreadCategory = discussionForumService.fetchByCategoryName(
					discussionThreadCategoryParent.getCategoryName());
			
			if(mainParentDiscussionThreadCategory != null)
				bindingResultParent.rejectValue("categoryName", UNIQUE_CONSTRAINT_VIOLATION_CODE, "Thread category already exist with name \""+discussionThreadCategoryParent.getCategoryName()+"\".");
			
			if (bindingResultParent.hasErrors()) 
			{
				redirectAttributes.addFlashAttribute("discussionThreadCategoryParentCreationModel", discussionThreadCategoryParent);
				redirectAttributes.addFlashAttribute(PARENT_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT, bindingResultParent);
				redirectAttributes.addFlashAttribute("modalIdHavingError", "ParentCategoryCreationModal");
				modelAndView.setViewName(DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION);
				return modelAndView;
			}
			
			try
			{
				discussionForumService.createDiscussionThreadCategory(discussionThreadCategoryParent);
				ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully created the thread category.");
				redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
			}
			catch (Exception e) 
			{
				ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
				redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
			}
		}
		
		
		//child
		if (discussionThreadCategorySubCategory.getParentCategory()!=null) 
		{

			DiscussionThreadCategory parentDiscussionThreadCategory = discussionForumService.fetchByCategoryName(
					discussionThreadCategorySubCategory.getParentCategory().getCategoryName());
			if(parentDiscussionThreadCategory == null)
				bindingResultSubCategory.rejectValue("parentCategory.categoryName", "Empty", "Select valid parent category.");
			
			DiscussionThreadCategory mainSubCategoryDiscussionThreadCategory = discussionForumService.fetchByCategoryName(
					discussionThreadCategorySubCategory.getCategoryName());
			if(mainSubCategoryDiscussionThreadCategory != null)
				bindingResultSubCategory.rejectValue("categoryName", UNIQUE_CONSTRAINT_VIOLATION_CODE, "Thread category already exist with name \""+discussionThreadCategorySubCategory.getCategoryName()+"\".");
			
			if (bindingResultSubCategory.hasErrors()) 
			{
				redirectAttributes.addFlashAttribute("discussionThreadCategorySubCategoryCreationModel", discussionThreadCategorySubCategory);
				redirectAttributes.addFlashAttribute(SUB_THREAD_CATEGORY_CREATION_MODEL_BINDING_RESULT, bindingResultSubCategory);
				redirectAttributes.addFlashAttribute("modalIdHavingError", "SubCategoryCreationModal");
				modelAndView.setViewName(DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION);
				return modelAndView;
			}
			
			if (parentDiscussionThreadCategory != null)
			{
				discussionThreadCategorySubCategory.setParentCategory(parentDiscussionThreadCategory);
				
				try
				{
					discussionForumService.createDiscussionThreadCategory(discussionThreadCategorySubCategory);
					ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully created the thread category.");
					redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
				}
				catch (Exception e) 
				{
					ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
					redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
				}
			}
		}
		
		return modelAndView;
	}
	
	
	/**
	 * @author Mukesh Dewangan
	 * @since 10 October 2018
	 * @param 	1> Path Variable - categoryName (String) 
	 * @return It will find thread category by category name and pass it to the jsp page for updation.
	 */
	@RequestMapping("/forum/Admin/updateDiscussionThreadCategory/{categoryName:.+}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView updateDiscussionThreadCategoryForm(@PathVariable("categoryName") String categoryName, RedirectAttributes redirectAttributes) 
	{
		DiscussionThreadCategory discussionThreadCategoryUpdationModel = discussionForumService.fetchByCategoryName(categoryName);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName(DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION);
		
		if(discussionThreadCategoryUpdationModel.getParentCategory() == null)
		{
			redirectAttributes.addFlashAttribute(PARENT_THREAD_CATEGORY_UPDATION_MODEL_NAME, discussionThreadCategoryUpdationModel);
			redirectAttributes.addFlashAttribute("modalIdHavingError", "ParentCategoryUpdationModal");
		}
		else if(discussionThreadCategoryUpdationModel.getParentCategory() != null)
		{
			redirectAttributes.addFlashAttribute(SUB_THREAD_CATEGORY_UPDATION_MODEL_NAME, discussionThreadCategoryUpdationModel);
			redirectAttributes.addFlashAttribute("modalIdHavingError", "SubCategoryUpdationModal");
		}
		
		return modelAndView;
	}
	

	/**
	 * @author Mukesh Dewangan
	 * @since 10 October 2018
	 * @param 	1> Model Attribute - discussionThreadCategoryParent (DiscussionThreadCategory) 
	 * 			2> Model Attribute - discussionThreadCategorySubCategory (DiscussionThreadCategory) 
	 * @return It will allow admin to update details of existing parent thread category or new sub-category.
	 */
	@RequestMapping("/forum/Admin/updateDiscussionThreadCategory")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView updateDiscussionThreadCategoryProcess(@ModelAttribute(PARENT_THREAD_CATEGORY_UPDATION_MODEL_NAME) @Valid DiscussionThreadCategory discussionThreadCategoryParent, BindingResult bindingResultParent, 
			@ModelAttribute(SUB_THREAD_CATEGORY_UPDATION_MODEL_NAME) @Valid DiscussionThreadCategory discussionThreadCategorySubCategory, BindingResult bindingResultSubCategory, 
			RedirectAttributes redirectAttributes) 
	{
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName(DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION);

		//parent
		if (discussionThreadCategoryParent.getParentCategory()==null)
		{
			DiscussionThreadCategory mainParentDiscussionThreadCategory = discussionForumService.fetchByCategoryName(
					discussionThreadCategoryParent.getCategoryName());
			
			if( (mainParentDiscussionThreadCategory != null) && (mainParentDiscussionThreadCategory.getCategoryId() != discussionThreadCategoryParent.getCategoryId()) )
				bindingResultParent.rejectValue("categoryName", UNIQUE_CONSTRAINT_VIOLATION_CODE, "Thread category already exist with name \""+discussionThreadCategoryParent.getCategoryName()+"\".");
			
			if (bindingResultParent.hasErrors()) 
			{
				modelAndView.setViewName(DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION);
				redirectAttributes.addFlashAttribute(PARENT_THREAD_CATEGORY_UPDATION_MODEL_NAME,discussionThreadCategoryParent);
				redirectAttributes.addFlashAttribute("modalIdHavingError", "ParentCategoryUpdationModal");
				redirectAttributes.addFlashAttribute(PARENT_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT, bindingResultParent);
				return modelAndView;
			}
			
			
			try
			{
				discussionForumService.updateDiscussionThreadCategory(discussionThreadCategoryParent);
				ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully updated the thread category.");
				redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
			}
			catch (Exception e) 
			{
				ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
				redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
			}
		}
		
		

		//child
		if (discussionThreadCategorySubCategory.getParentCategory()!=null) 
		{

			DiscussionThreadCategory parentDiscussionThreadCategory = discussionForumService.fetchByCategoryName(
					discussionThreadCategorySubCategory.getParentCategory().getCategoryName());
			if(parentDiscussionThreadCategory == null)
				bindingResultSubCategory.rejectValue("parentCategory.categoryName", "Empty", "Select valid parent category.");
			
			DiscussionThreadCategory mainSubCategoryDiscussionThreadCategory = discussionForumService.fetchByCategoryName(
					discussionThreadCategorySubCategory.getCategoryName());
			
			if( (mainSubCategoryDiscussionThreadCategory != null) && (mainSubCategoryDiscussionThreadCategory.getCategoryId() != discussionThreadCategorySubCategory.getCategoryId()) )
				bindingResultSubCategory.rejectValue("categoryName", UNIQUE_CONSTRAINT_VIOLATION_CODE, "Thread category already exist with name \""+discussionThreadCategorySubCategory.getCategoryName()+"\".");
			
			if (bindingResultSubCategory.hasErrors()) 
			{
				redirectAttributes.addFlashAttribute(SUB_THREAD_CATEGORY_UPDATION_MODEL_NAME, discussionThreadCategorySubCategory);
				redirectAttributes.addFlashAttribute(SUB_THREAD_CATEGORY_UPDATION_MODEL_BINDING_RESULT, bindingResultSubCategory);
				redirectAttributes.addFlashAttribute("modalIdHavingError", "SubCategoryUpdationModal");
				modelAndView.setViewName(DISCUSSION_FORUM_THREAD_CATEGORIES_REDIRECTION);
				return modelAndView;
			}
			
			if (parentDiscussionThreadCategory != null)
			{
				discussionThreadCategorySubCategory.setParentCategory(parentDiscussionThreadCategory);
				
				try
				{
					discussionForumService.updateDiscussionThreadCategory(discussionThreadCategorySubCategory);
					ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.SUCCESS, "You have succesfully updated the thread category.");
					redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
				}
				catch (Exception e) 
				{
					ResponseMessage responseMessage = new ResponseMessage(ResponseMessageStatus.ERROR, ERROR_MESSAGE);
					redirectAttributes.addFlashAttribute(RESPONSE_PARAMETER, responseMessage);
				}
			}
		}
		
		return modelAndView;
	}
	
	
}
