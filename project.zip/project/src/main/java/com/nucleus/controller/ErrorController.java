package com.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ErrorController 
{
	/**
	 * @author Mukesh Dewangan
	 * @since 28 October 2018
	 * @return It will return 404 error page.
	 */
	@RequestMapping("404")
	public String errorCode404()
	{
		return "ErrorPage/404ErrorPage";
	}
}
