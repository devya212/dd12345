package com.nucleus.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.service.UserService;

/**
 * @author Vishal Talwar
 * @since September 2018
 */
@Controller
public class NewUserController {

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/newUserRegistration")
	public ModelAndView newUser() {
		return new ModelAndView("Registration", "userPojo", new PFinnNewUser());
	}

	/*@RequestMapping(value = "/formsubmit")
	public ModelAndView newMember(@ModelAttribute("userPojo") PFinnNewUser userPojo, Model m , HttpServletRequest request) {
		int exist = userService.checkUnique(userPojo);
		if (exist == 0) {
			userService.newMember(userPojo); // adding new user or admin
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Your request has been send!   Waiting for Approval!");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/',true");
			return model;
		} else {
			m.addAttribute("message", "User Name or Email Already exist");
			return new ModelAndView("Registration");

		}
	}*/
	

	
	
	@RequestMapping(value = "/formsubmit",method=RequestMethod.POST)
	public ModelAndView newMember(@ModelAttribute("userPojo") @Valid PFinnNewUser userPojo,BindingResult results, HttpServletRequest request) {
		System.out.println("/////////////////////////////////////////////////////////////");
		int exist = userService.checkUnique(userPojo);
		System.out.println(userPojo.getFirstName()+"+++++++++");
		
		if(results.hasErrors()){
			System.out.println("in if");

		ModelAndView model = new ModelAndView("Registration");
	/*	System.out.println("@@@@@@");
			model.addObject("alertMessage", "One of the field is wrongly added !!");*/

		        return model;
		}
		else if (exist == 0) {
			System.out.println("in elseif********************************");
			userService.newMember(userPojo); // adding new user or admin
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Your request has been send!   Waiting for Approval!");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/',true");
			return model;
		} 
	else {		System.out.println("abe yaar");
		System.out.println("++++++++++++++++++++++++++++++++++in else+++++++++++++++++");
		ModelAndView model=new ModelAndView("Registration");
			model.addObject("message", "User Name or Email Already exist");
			
			return model;

		}
		
	}
}
