package com.nucleus.controller;

import java.security.Principal;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.PFinnUserContribution;
import com.nucleus.service.CategoryService;
import com.nucleus.service.UserService;

@Controller
public class LoginController {

	@Autowired
	UserService userService;
	
	@Autowired
	CategoryService categoryService;


	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	/**
	 * This Function Helps to open the First login Page
	 */
	@RequestMapping(value = "/")
	public String welcome(HttpServletRequest request) {

		String randomKey = UUID.randomUUID().toString();
		String uniqueKey = randomKey.substring(randomKey.length()-17, randomKey.length() -1);
		request.getSession().setAttribute("key", uniqueKey);
		return "login";
	}

	/**
	 * This Function Helps in redirecting to Login Page After Logout
	 *
	 **/
	@RequestMapping(value = "/logout1", method = RequestMethod.GET)
	public String logout1() {
		return "redirect:/";
	}

	/**
	 * 
	 * This Function Helps To redirect User to user's welcome page after login.
	 */

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView home(Model m, Principal principle , HttpServletRequest request)

	{

		int approved = userService.checkApprovalStatus(principle.getName());
		if (approved == 1) {
			logger.info("i am at user page");
			m.addAttribute("user", principle.getName());
			return new ModelAndView("welcomeUser");
		} else {
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Cannot Login!   Approval Pending");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/',true");
			return model;
		}

	}

	/**
	 * 
	 * This Function Helps To redirect Admin to admin's welcome page after
	 * login.
	 */

	@RequestMapping(value = "/adminHome", method = RequestMethod.GET)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String home1(Model m, Principal principal)

	{
		logger.info("i am at admin page");
		m.addAttribute("user", principal.getName());
		return "welcome";// welcome

	}

	/**
	 * 
	 * This Function Helps To redirect to "You Are not authorized" page when
	 * someone tries to copy paste url which he cannot access on the basis of
	 * role defined in database.
	 */

	@RequestMapping(value = "/accessDenied", method = RequestMethod.GET)
	public ModelAndView access(HttpServletRequest request)

	{

		ModelAndView model = new ModelAndView("alert");
		model.addObject("alertMessage", "YOU ARE NOT AUTHORIZED TO ENTER HERE");
		model.addObject("location", "document.location.href = '"+request.getContextPath()+"/',true");
		return model;

	}

	/**
	 * This Function gives an alert when someone puts wrong credentials
	 */
	@RequestMapping(value = "/alert", method = RequestMethod.GET)
	public ModelAndView alert(HttpServletRequest request)

	{
		logger.info("i am at alert page");
		ModelAndView model = new ModelAndView("alert");
		model.addObject("alertMessage", "Invalid credentials");
		model.addObject("location", "document.location.href = '"+request.getContextPath()+"/',true");
		return model;

	}

	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String error()

	{

		return "error";

	}

	@RequestMapping(value = "/Product", method = RequestMethod.GET)
	public String home12()

	{
		logger.info("i am at admin page");
		return "Product";// welcome

	}

	@RequestMapping(value = "/ProductFeedback", method = RequestMethod.GET)
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView productfeedback() {
		ModelAndView modelAndView = new ModelAndView("ProductFeedback");
		Map<String, String> pFinnCategoryList = userService.category();
		modelAndView.addObject("pFinnCategoryList", pFinnCategoryList);
		modelAndView.addObject("pFinnUserContribution", new PFinnUserContribution());
		return modelAndView;
	}
	
	@RequestMapping(value = "/concurrecyControl", method = RequestMethod.GET)
	public ModelAndView sessionAlertConcurrencyControl(HttpServletRequest request)

	{
		ModelAndView model = new ModelAndView("alert");
		model.addObject("alertMessage", "One other session has already been created");
		model.addObject("location", "document.location.href = '"+request.getContextPath()+"/',true");
		return model;

	}

}
