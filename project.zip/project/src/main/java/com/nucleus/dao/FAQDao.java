package com.nucleus.dao;

import java.util.List;

import com.nucleus.pojo.FAQ;

public interface FAQDao {

	public void saveFAQ(FAQ faq);

	public List<FAQ> getAllFAQ();

	public List<FAQ> getFilteredFAQ(String searchString);
	

}
