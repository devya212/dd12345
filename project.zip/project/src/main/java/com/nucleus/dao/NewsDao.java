package com.nucleus.dao;

import java.util.ArrayList;

import com.nucleus.pojo.News;

public interface NewsDao {
	public boolean writeToDB(News news);

	public ArrayList<News> readFromDB();

	public ArrayList<News> readHeadlineFromDB();

	public int archiveFromDB(ArrayList<News> newsList);

	public News fetchFromDBUsingId(int newsid);

	public int writeUpdateToDB(News news);

	public ArrayList<News> readHeadlineFromDB1();

	public int unarchiveFromDB1(ArrayList<News> newsList);

	public News getPdf(int idOfPdfToBeDownloaded);

}
