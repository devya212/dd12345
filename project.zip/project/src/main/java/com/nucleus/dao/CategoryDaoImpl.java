package com.nucleus.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.nucleus.pojo.DiscussionThreadCategory;
@Repository
public class CategoryDaoImpl implements CategoryDao
{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<DiscussionThreadCategory> getCategoryForQuiz() {
		return entityManager.createQuery("from DiscussionThreadCategory", DiscussionThreadCategory.class).getResultList();
	}

}
