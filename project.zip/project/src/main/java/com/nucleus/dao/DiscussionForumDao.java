package com.nucleus.dao;

import java.util.List;

import com.nucleus.pojo.DiscussionPost;
import com.nucleus.pojo.DiscussionThread;
import com.nucleus.pojo.DiscussionThreadCategory;
import com.nucleus.pojo.PFinnNewUser;

public interface DiscussionForumDao 
{
	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public DiscussionThread getDiscussionThreadByThreadId(int threadId);

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public List<DiscussionPost> getApprovedDeletedPostsOfThread(DiscussionThread discussionThread, int pageNo, int perPageRecord);

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public void postCommentOnThread(DiscussionPost discussionPost);

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public int getTotalNoOfApprovedPostOfUser(PFinnNewUser pFinnNewUser);
	
	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public void changeDiscussionThreadStatus(int threadId);

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public void deletePost(int postId);

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public DiscussionPost getDiscussionPostByDiscussionPostId(int discussionPostId);

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 */
	public List<DiscussionThread> getThreads(DiscussionThreadCategory discussionThreadCategory, String order, int pageNo, int perPageRecord);
	
	/**
	 * @author Mukesh Dewangan
	 * @since 30 December 2018
	 */
	public List<Integer> getTopThreads(DiscussionThreadCategory discussionThreadCategory, int pageNo, int perPageRecord);

	/**
	 * @author Mukesh Dewangan
	 * @since 30 December 2018
	 */
	public List<Integer> getLatestThreads(DiscussionThreadCategory discussionThreadCategory, int pageNo, int perPageRecord);
	
	//======================================================================================
	
	
	/**
	 * @author Vasu Sharma
	 * @since 24 September 2018
	 */
	public void createThread(DiscussionThread discussionThread);
	
	/**
	 * @author Vasu Sharma
	 * @since 24 September 2018
	 */
	public List<DiscussionThread> getThreadsByCategory(int categoryId);
	
	/**
	 * @author Vasu Sharma
	 * @since 24 September 2018
	 */
	public List<DiscussionThread> getThreadsByCategory2(int categoryId);
	
	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 */
	public List<DiscussionThreadCategory> getCategories(int categoryId);

	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 */
	public void addUserToViewListOfDiscussionThread(PFinnNewUser user, DiscussionThread discussionThread);

	/**
	 * @author Vasu Sharma
	 * @since 04 October 2018
	 */
	public void createDiscussionThreadCategory(DiscussionThreadCategory discussionThreadCategory);
	
	/**
	 * @author Vasu Sharma
	 * @since 04 October 2018
	 */
	public void updateDiscussionThreadCategory(DiscussionThreadCategory discussionThreadCategory);
	//======================================================================================
	
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 */
	public List<DiscussionPost> viewAll(); 
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 */
	public void updatePostStatus(List<DiscussionPost> discussionPostList);
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 */
	public DiscussionThreadCategory fetchByCategoryName(String categoryName);
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 */
	public void updateThread(DiscussionThread discussionThread);

	/**
	 * @author Ajita Mittal
	 * @since 23 November 2018
	 */
	public List<DiscussionThread> searchDiscussionThreads(String searchString);
	

//	===============================================Mukesh
	
	public List<DiscussionThreadCategory> test();
	
}



