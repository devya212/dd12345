package com.nucleus.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nucleus.pojo.Badge;

import com.nucleus.pojo.EventMaster;
import com.nucleus.pojo.Gifts;
import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.pojo.PFinnUserContribution;
import com.nucleus.pojo.UserReward;
import com.nucleus.pojo.UserTransaction;

@Repository
public class PointTransactionDaoImpl implements PointTransactionDao {
	// transactions of point management system

	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<PFinnUserContribution> fetch() {
		Query query = entityManager.createQuery("from PFinnUserContribution");
		return query.getResultList();
	} // Hatana Hai

	// ===========================================================================================================================

	@Override
	public long fetchUserId(String username) {
		Query query = entityManager.createQuery("from PFinnNewUser where username=? ");
		query.setParameter(1, username);
		PFinnNewUser newUser = (PFinnNewUser) query.getSingleResult();
		return newUser.getUserID();
	}

	@Override
	public UserReward fetchRewardTable(long userId) {
		Query query = entityManager.createQuery("from UserReward where userId=?");
		query.setParameter(1, userId);
		try {
			return (UserReward) query.getSingleResult();
		} catch (Exception e) {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserTransaction> fetchTransactionTable(long userId) {
		Query query = entityManager.createQuery("from UserTransaction where userId=?");
		query.setParameter(1, userId);
		return query.getResultList();
	}

	@Override
	public int totalContribution(long userId) {
		Query query = entityManager.createQuery("from UserTransaction where userid=? and transactionType=?");
		query.setParameter(1, userId);
		query.setParameter(2, "Deposit");
		return query.getResultList().size();
	}

	public int totalFeedback(long userId) {
		Query query = entityManager
				.createQuery("from UserTransaction where userid=? and transactionType=? and eventtype=?");
		query.setParameter(1, userId);
		query.setParameter(2, "Deposit");
		query.setParameter(3, "FEEDBACK");
		return query.getResultList().size();
	}

	public int totalSuggestions(long userId) {
		Query query = entityManager
				.createQuery("from UserTransaction where userid=? and transactionType=? and eventtype=?");
		query.setParameter(1, userId);
		query.setParameter(2, "Deposit");
		query.setParameter(3, "SUGGESTION");
		return query.getResultList().size();
	}

	public int totalNewIdeas(long userId) {
		Query query = entityManager
				.createQuery("from UserTransaction where userid=? and transactionType=? and eventtype=?");
		query.setParameter(1, userId);
		query.setParameter(2, "Deposit");
		query.setParameter(3, "NEWIDEA");
		return query.getResultList().size();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserTransaction> getDepositPoints(long userId) {
		Query query = entityManager.createQuery("from UserTransaction where userId=? and transactionType=?");
		query.setParameter(1, userId);
		query.setParameter(2, "Deposit");
		return query.getResultList();
	}

	@Override
	public int fetchRewardPointsFromEventMaster(PFinnUserContribution contribution) {
		Query query = entityManager.createQuery("from EventMaster p where p.eventType=? and p.rating=?");
		query.setParameter(1, contribution.getEventType());
		query.setParameter(2, contribution.getRating());
		EventMaster master = (EventMaster) query.getSingleResult();
		return master.getRewardPoints();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PFinnUserContribution> fetchNewTransaction() {
		try {
			Query query = entityManager.createQuery(
					"from PFinnUserContribution where statusDate>(select max(To_DATE(transactionDate, 'dd/MM/yyyy hh:mi:ss PM')) from UserTransaction) AND status='APPROVED'");
			return query.getResultList();
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public void saveToTransactionTable(UserTransaction transaction) {
		entityManager.merge(transaction);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserTransaction> getWithdrawalPoints(long userId) {
		Query query = entityManager.createQuery("from UserTransaction where userid=? and transactionType=? ");
		query.setParameter(1, userId);
		query.setParameter(2, "Withdrawal");
		return query.getResultList();
	}

	@Override
	public void pushToRewardTable(UserReward userReward) {
		entityManager.merge(userReward);
	}

	@Override
	public Gifts getGiftPoints(String giftName) {
		Query query = entityManager.createQuery("from Gifts where giftName=?");
		query.setParameter(1, giftName);
		return (Gifts) query.getSingleResult();
	}

	@Override
	public Badge getBadge(int rewardPoints) {
		try{
		Query query = entityManager.createQuery("from Badge where minPoint>=? and maxPoint<=?");
		query.setParameter(1, rewardPoints);
		query.setParameter(2, rewardPoints);
		return (Badge) query.getSingleResult();
	}
	
	catch(Exception e)
	{
		return null;
	}
	}

}
