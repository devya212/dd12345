package com.nucleus.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.nucleus.pojo.FAQ;

@Repository
public class FAQDaoImpl implements FAQDao {
	
	@PersistenceContext 
	private EntityManager entityManager;

	@Override
	public void saveFAQ(FAQ faq) {
		entityManager.persist(faq);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FAQ> getAllFAQ() {
		return entityManager.createQuery("from FAQ").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FAQ> getFilteredFAQ(String searchString) {
		return  entityManager.createQuery("from FAQ where "
				+ "lower(question) like concat('%',lower(:searchString),'%') or "
				+ "lower(answer) like concat('%',lower(:searchString),'%')")
				.setParameter("searchString", searchString)
				.getResultList();
	}
	
}
