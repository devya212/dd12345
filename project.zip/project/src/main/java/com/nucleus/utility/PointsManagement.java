package com.nucleus.utility;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

import com.nucleus.pojo.PFinnUserContribution;
import com.nucleus.pojo.UserReward;
import com.nucleus.pojo.UserTransaction;
import com.nucleus.service.PointTransactionService;

@Component
public class PointsManagement {
	@Autowired
	PointTransactionService pService;

	UserTransaction transaction = new UserTransaction();


	public int calculateAvailablePoints(long userId) {

		int dSum = 0;
		int wSum = 0;
		List<UserTransaction> ut = pService.getDepositPoints(userId);
		
		for (UserTransaction u : ut) {
			System.out.println(u.getAmount());
			dSum = dSum + u.getAmount();
		}
		ut = pService.getWithdrawalPoints(userId);
		for (UserTransaction u : ut) {
			wSum = wSum + u.getAmount();
		}

		UserReward userReward = new UserReward();
		userReward.setUserId(userId);
		userReward.setAvailablePoints(dSum - wSum);
		
		try
		{
		userReward.setBatch(pService.getBadge(dSum - wSum).getBadgeName());
		pService.pushToRewardTable(userReward);
		return (dSum - wSum);
		}
		
		catch (Exception e) {
		return 0;	
		}
	}

	public long getUserId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User user = (User) auth.getPrincipal();
		String name = user.getUsername();
		return pService.fetchUserId(name);
	}

	public List<UserTransaction> changeTime(List<UserTransaction> ul) {
		for (UserTransaction u : ul) {
			String str = u.getTransactionDate().substring(0, 16) + u.getTransactionDate().substring(19, 22);
			u.setTransactionDate(str);

		}
		return ul;

	}

	public void transaction() {
		List<PFinnUserContribution> c = pService.fetchNewTransaction();
		for (PFinnUserContribution contribution : c) {
			int rewardPoints = pService.fetchRewardPointsFromEventMaster(contribution);
			transaction.setAmount(rewardPoints);
			transaction.setEventType(contribution.getEventType());
			transaction.setEventId(contribution.getEventId());
			transaction.setUserId(contribution.getpFinnNewUser().getUserID());
			transaction.setTransactionType("Deposit");
			Date date = new Date();
			SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
			transaction.setTransactionDate(simple.format(date));
			pService.saveToTransactionTable(transaction);
			this.calculateAvailablePoints(contribution.getpFinnNewUser().getUserID());
		}
	}

	public void redeem(int redeemPoints, long userId2) {
		// int
		// rewardPoints=pService.fetchRewardPointsFromEventMaster(contribution);
		transaction.setAmount(redeemPoints);
		transaction.setEventType("Redeem");
		transaction.setEventId(0);
		transaction.setUserId(userId2);
		transaction.setTransactionType("Withdrawal");
		Date date = new Date();
		SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		transaction.setTransactionDate(simple.format(date));
		pService.saveToTransactionTable(transaction);
		this.calculateAvailablePoints(userId2);

	}
}
