package com.nucleus.utility;


/**
 * @author Mukesh Dewangan
 * @since 5 December 2018
 * This is the utility class that contains the method for search operations.
 */
public class SearchParameterOperation 
{
	/**
	 * @author Mukesh Dewangan
	 * @since 5 December 2018
	 * This method accept the original string and search parameter and change the style of this searched parameter in the original string.
	 */
	public static String changeColorOfSearchedString(String originalString, String searchedParameter)
	{
		String text = originalString.toLowerCase();
		String match = searchedParameter.toLowerCase();
		
		int index = text.indexOf(match);
		int matchLength = match.length();
		while (index >= 0) 
		{
		    String foundSubstring = originalString.substring(index, index+matchLength);
		    String replacementSubstring = "<span style='font-weight: bolder; color: #000;'>"+foundSubstring+"</span>";
		    originalString = originalString.substring(0, index) + originalString.substring(index).replaceFirst(foundSubstring, replacementSubstring);
		    text = originalString.toLowerCase();
		    index = text.indexOf(match, index + replacementSubstring.length());
		}

		return originalString;
	}
}
