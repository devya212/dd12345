package com.nucleus.utility;


/**
 * @author Mukesh Dewangan
 * @since 12 October 2018
 * It will be used to show response messages
 */
public class ResponseMessage 
{
	public enum ResponseMessageStatus
	{
		SUCCESS, ERROR;
	}
	
	private ResponseMessageStatus status;
	
	private String message;
	
	public ResponseMessage() {
		
	}

	public ResponseMessage(ResponseMessageStatus status, String message) {
		super();
		this.status = status;
		this.message = message;
	}

	public ResponseMessageStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseMessageStatus status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ResponseMessage [status=" + status + ", message=" + message + "]";
	}

}
