package com.nucleus.filter;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import com.nucleus.functions.AesUtil;

/**
 * @author Mukesh Dewangan
 * @since 18 November 2018
 * This Request wrapper will change the request. It will decrypt the received password using aes method and store it in the request.
 */
public class UsernamePasswordAuthenticationRequestWrapper  extends HttpServletRequestWrapper
{
	private String key;
	
	public UsernamePasswordAuthenticationRequestWrapper(ServletRequest request) {
		super((HttpServletRequest) request);
		key = (String) ((HttpServletRequest) request).getSession().getAttribute("key"); 
		((HttpServletRequest) request).getSession().removeAttribute("key");
	}
		
	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * When this method will be called, it will check if paramName is "j_password" then it will decrypt the value of "j_password" field.
	 */
	public String getParameter(String paramName) {
        String value = super.getParameter(paramName);
        if ("j_password".equals(paramName)) {
            value = decryptPassword(value);
        }
        return value;
    }

	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * When this method will be called, it will check if paramName is "j_password" then it will decrypt the value of "j_password" field.
	 */
    public String[] getParameterValues(String paramName) {
        String values[] = super.getParameterValues(paramName);
        if ("j_password".equals(paramName)) {
            for (int index = 0; index < values.length; index++) {
                values[index] = decryptPassword(values[index]);
            }
        }
        return values;
    }
    

	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * This method will decrypt the password using AES method and return the original password.
	 */
    public String decryptPassword(String password)
    {
    	String decryptedPassword =  new String(java.util.Base64.getDecoder().decode(password));
		AesUtil aesUtil = new AesUtil(128, 1000);
        if (decryptedPassword != null && decryptedPassword.split("::").length == 3) {
        	String salt = decryptedPassword.split("::")[1]; 
    		String four = decryptedPassword.split("::")[0];
    		String passphrase = this.key; 
    		String cipherText = decryptedPassword.split("::")[2]; 
        	String originalPassword = aesUtil.decrypt(salt, four, passphrase, cipherText);
        	return originalPassword;
        }
		return password;
    }
	
	
}