package com.nucleus.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;


/**
 * @author Mukesh Dewangan
 * @since 5 december 2018
 */
public class HTMLFilterRequestWrapper extends HttpServletRequestWrapper
{

	HTMLFilter htmlFilter = new HTMLFilter();
	
	public HTMLFilterRequestWrapper(HttpServletRequest request) {
		super(request);
	}
	
	@Override
	public String getParameter(String name) {
		String value = super.getParameter(name);
		if(value != null)
			value = htmlFilter.filter(value).trim();
		return value;
	}

		
	@Override
	public String[] getParameterValues(String name) {
		String values[] = super.getParameterValues(name);
		if(values != null)
		{
	        for (int index = 0; index < values.length; index++) {
	        	if(values[index] != null)
	        		values[index] = htmlFilter.filter(values[index]).trim();
	        }
		}
		return values;
	}
}
