package com.nucleus.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.nucleus.dao.NewsDao;
import com.nucleus.functions.ImageConversion;
import com.nucleus.pojo.News;

@Service
@Transactional
public class NewsServiceImpl implements NewsService {
	@Autowired
	private NewsDao newsDao;

	@Override
	public int writeToDB(News news, MultipartFile filePart) {
		ImageConversion ic = new ImageConversion();
		// String image = ic.convert(filePart);

		news.setNewsImage(ic.convert(filePart));
		boolean c = newsDao.writeToDB(news);
		if (c == true) {
			return 1;
		} else {
			return 0;
		}

	}

	@Override
	public ArrayList<News> readFromDB() {
		ArrayList<News> list = new ArrayList<News>();
		list = newsDao.readFromDB();
		return list;
	}

	@Override
	public ArrayList<News> readHeadlineFromDB() {

		return newsDao.readHeadlineFromDB();

	}

	@Override
	public int archiveFromDB(ArrayList<News> newsList) {

		return newsDao.archiveFromDB(newsList);
	}

	@Override
	public News fetchFromDBUsingId(int newsid) {

		return newsDao.fetchFromDBUsingId(newsid);
	}

	@Override
	public int writeUpdateToDB(News news, MultipartFile filePart) {
		ImageConversion ic = new ImageConversion();
		String image = ic.convert(filePart);
		news.setNewsImage(image);
		int c = newsDao.writeUpdateToDB(news);
		return c;

	}

	@Override
	public ArrayList<News> readHeadlineFromDB1() {
		return newsDao.readHeadlineFromDB1();
	}

	@Override
	public int unarchiveFromDB1(ArrayList<News> newsList) {

		return newsDao.unarchiveFromDB1(newsList);
	}

	@Override
	public News getPdf(int idOfPdfToBeDownloaded) {
		return newsDao.getPdf(idOfPdfToBeDownloaded);
	}

}
