package com.nucleus.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.DiscussionForumDao;
import com.nucleus.pojo.DiscussionPost;
import com.nucleus.pojo.DiscussionThread;
import com.nucleus.pojo.DiscussionThreadCategory;
import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.utility.DiscussionForumThreadListView;

@Service
public class DiscussionForumServiceImplementation implements DiscussionForumService
{
	
	@Autowired
	DiscussionForumDao discussionForumDao;

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param int - threadId: accept single integer threadId to fetch single discussion thread
	 * @return DiscussionThread : Single discussion thread object of given threadId
	 * This function will accept integer threadId and calls getDiscussionThreadByThreadId() method of discussionForumDao 
	 * and pass accepted parameter as method variable arguments.
	 */
	@Override
	@Transactional(readOnly=true)
	public DiscussionThread getDiscussionThreadByThreadId(int threadId) {
		return discussionForumDao.getDiscussionThreadByThreadId(threadId);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> DiscussionThread - discussionThread: Single discussion thread object
	 * 			2> int - pageNo: current page no to return the object for that page no
	 * 			3> int - perPageRecord: how many post should be selected from the database
	 * @return List<DiscussionPost> : List of post objects of given discussion thread according to given page no and per page record
	 * This function will accept discussion thread object, page no and per page record 
	 * and calls getApprovedPostsOfThread() method of discussionForumDao and pass given variable as method variables arguments.
	 */
	@Override
	@Transactional(readOnly=true)
	public List<DiscussionPost> getApprovedDeletedPostsOfThread(DiscussionThread discussionThread, int pageNo, int perPageRecord) {
		return discussionForumDao.getApprovedDeletedPostsOfThread(discussionThread, pageNo, perPageRecord);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> DiscussionPost - discussionPost: accept single discussion post
	 * 			2> int - threadId: single threadId to fetch thread object
	 * @return none 
	 * This function will accept discussion post and threadId. 
	 * Then it will fetch the thread by given thread id and set it to the data member of given discussion post.
	 * It also set the system time as postedDate in the discussion post and calls postCommentOnThread() method of discussionForumDao
	 * and pass accepted discussionPost parameter as method variable arguments.
	 */
	@Override
	@Transactional(readOnly=false)
	public void postCommentOnThread(DiscussionPost discussionPost, int threadId) {
		discussionPost.setDiscussionThread(this.getDiscussionThreadByThreadId(threadId));
		discussionPost.setPostedDate(new Date(System.currentTimeMillis()));
		
		if(discussionPost.getQuotedDiscussionPost().getDiscussionPostId() != 0)
			discussionPost.setQuotedDiscussionPost(discussionForumDao.getDiscussionPostByDiscussionPostId(discussionPost.getQuotedDiscussionPost().getDiscussionPostId()));
		else
			discussionPost.setQuotedDiscussionPost(null);
		
		/*if(discussionForumDao.getTotalNoOfApprovedPostOfUser(discussionPost.getPostedByUser())>10)
		{
			discussionPost.setStatus("APPROVED");
			discussionPost.setStatusTime(new Date(System.currentTimeMillis()));
		}*/
		discussionForumDao.postCommentOnThread(discussionPost);
	}
	
	/**
	 * @author Mukesh Dewangan
	 * @since 10 October 2018
	 * @param int - threadId: accept single discussion thread id
	 * @return none 
	 * This function will change the status of discussion thread in the database from OPEN->CLOSED / CLOSED->OPEN
	 */
	@Override
	@Transactional(readOnly=false)
	public void changeDiscussionThreadStatus(int threadId) {
		discussionForumDao.changeDiscussionThreadStatus(threadId);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 10 October 2018
	 * @param int - postId: accept single discussion post id
	 * @return none 
	 * This function will accept single discussion post id and change its status to DELETED.
	 */
	@Override
	@Transactional(readOnly=false)
	public void deletePost(int postId) {
		discussionForumDao.deletePost(postId);
	}
	
	/**
	 * @author Mukesh Dewangan
	 * @since 29 September 2018
	 * @param 	1> DiscussionThreadCategory - discussionThreadCategory: accept single discussion thread category
	 * 			2> String - order: order for posted-date ascending/descending
	 * 			3> int - pageNo:current page-no
	 * 			4> int - perPageRecord: per-page-record
	 * @return List<DiscussionForumThreadListView> - return list of discussion threads for view
	 * This function will accept single discussion thread category, order, current page-no and per-page-record and return list of discussion threads with "OPEN" and "CLOSED" status for view.
	 */
	@Override
	@Transactional(readOnly=true)
	public List<DiscussionForumThreadListView> getNewestOldestThreads(DiscussionThreadCategory discussionThreadCategory, String order, int pageNo, int perPageRecord)
	{
		List<DiscussionForumThreadListView> discussionForumThreadListView = new ArrayList<>();
		for(DiscussionThread discussionThread: discussionForumDao.getThreads(discussionThreadCategory, order, pageNo, perPageRecord))
		{
			List<DiscussionPost> totalApprovedPost = discussionForumDao.getApprovedDeletedPostsOfThread(discussionThread, 0, 0);
			DiscussionPost lastPost = null;
			int totalNoOfApprovedPost = totalApprovedPost.size();
			if(totalApprovedPost != null && !totalApprovedPost.isEmpty())
				lastPost = totalApprovedPost.get(totalApprovedPost.size()-1);
			discussionForumThreadListView.add(new DiscussionForumThreadListView(discussionThread, lastPost, totalNoOfApprovedPost));
		}
		return discussionForumThreadListView;
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 30 December 2018
	 * @param 	1> DiscussionThreadCategory - discussionThreadCategory : accept thread category name
	 * 			2> String - type : thread listing type "Latest" / "Top"
	 * 			3> int - pageNo : current page-no
	 * 			4> int - perPageRecord : per-page-record
	 * @return List<DiscussionForumThreadListView> - return list of discussion threads for view
	 * This function will accept single discussion thread category, order, current page-no and per-page-record and return list of discussion threads with "OPEN" and "CLOSED" status for view according to order type either "top" or "latest".
	 */
	@Override
	@Transactional(readOnly=true)
	public List<DiscussionForumThreadListView> getTopLatestThreads(DiscussionThreadCategory discussionThreadCategory, String type, int pageNo, int perPageRecord)
	{
		List<DiscussionForumThreadListView> discussionForumThredListView = new ArrayList<>();
		List<Integer> threadIds = new ArrayList<>();
		if(type.equalsIgnoreCase("top"))
			threadIds = discussionForumDao.getTopThreads(discussionThreadCategory, pageNo, perPageRecord);
		else if(type.equalsIgnoreCase("latest"))
			threadIds = discussionForumDao.getLatestThreads(discussionThreadCategory, pageNo, perPageRecord);
		
		for (Integer threadId : threadIds)
		{
			DiscussionThread discussionThread = discussionForumDao.getDiscussionThreadByThreadId(threadId);
			List<DiscussionPost> totalApprovedPost = discussionForumDao.getApprovedDeletedPostsOfThread(discussionThread, 0, 0);
			DiscussionPost lastPost = null;
			int totalNoOfApprovedPost = totalApprovedPost.size();
			if(totalApprovedPost != null && !totalApprovedPost.isEmpty())
				lastPost = totalApprovedPost.get(totalApprovedPost.size()-1);
			discussionForumThredListView.add(new DiscussionForumThreadListView(discussionThread, lastPost, totalNoOfApprovedPost));
		}
		return discussionForumThredListView;
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 29 September 2018
	 * @param 	1> String - categoryName: accept thread category name
	 * 			2> String - threadsListingType: thread listing type "Latest" / "Top" / "Newest" / "Oldest"
	 * 			3> int - pageNo: current page-no
	 * 			4> int - perPageRecord: per-page-record
	 * @return List<DiscussionForumThreadListView> - return list of discussion threads for view
	 * This function will accept single discussion thread category, order, current page-no and per-page-record and return list of discussion threads with "OPEN" and "CLOSED" status for view.
	 */
	@Override
	@Transactional(readOnly=true)
	public List<DiscussionForumThreadListView> getDiscussionThreads(String categoryName, String threadsListingType,
			int pageNo, int perPageRecord) {
		
		DiscussionThreadCategory discussionThreadCategory = null;
		if(categoryName != null && !categoryName.equalsIgnoreCase(""))
			discussionThreadCategory = discussionForumDao.fetchByCategoryName(categoryName);
				
		if(threadsListingType.equalsIgnoreCase("Latest"))
			return this.getTopLatestThreads(discussionThreadCategory, "latest", pageNo, perPageRecord);
		else if(threadsListingType.equalsIgnoreCase("Top"))
			return this.getTopLatestThreads(discussionThreadCategory, "top", pageNo, perPageRecord);
		else if(threadsListingType.equalsIgnoreCase("Newest"))
			return this.getNewestOldestThreads(discussionThreadCategory, "newest", pageNo, perPageRecord);
		else if(threadsListingType.equalsIgnoreCase("Oldest"))
			return this.getNewestOldestThreads(discussionThreadCategory, "oldest", pageNo, perPageRecord);
		
		return new ArrayList<>();
	}

	//======================================================================================
	
	
	/**
	 * @author Vasu Sharma
	 * @since 24 September 2018
	 * @param discussionThread object reference with filled data by admin
	 */
	@Transactional
	@Override
	public void createThread(DiscussionThread discussionThread) {
		discussionForumDao.createThread(discussionThread);
	}

	/**
	 * @author Vasu Sharma
	 * @since 24 September 2018
	 * @param categoryId for which we want to get the discussion threads
	 * @return list of Discussion Threads 
	 */
	@Transactional(readOnly=true)
	@Override
	public List<DiscussionThread> getThreadsByCategory(int categoryId) {
		return discussionForumDao.getThreadsByCategory(categoryId);
	}

	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 * @param categoryId should be -1 for getting parent categories 
	 * 		  and specific categoryId for getting child categories (sub-categories) 
	 * @return list of Discussion Thread Category 
	 */
	@Transactional(readOnly=true)
	@Override
	public List<DiscussionThreadCategory> getCategories(int categoryId) {
		return discussionForumDao.getCategories(categoryId);
	}
	
	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 * @param PFinnNewUser user : User object  
	 * @param DiscussionThread discussionThread : Thread object ,
	 * 		  for which we need to find if this user object has viewed this thread or not.
	 */
	@Override
	@Transactional(readOnly=false)
	public void checkIfUserHasViewedThisThread(PFinnNewUser user, DiscussionThread discussionThread) {
		boolean alreadyViewed = false;
		for(PFinnNewUser user_i : discussionThread.getUsersWhoHaveViewedThisThread()){
			if(user_i.getUsername().equals(user.getUsername())){
				alreadyViewed = true;
				break;
			}
		}
		if (!alreadyViewed)
			discussionForumDao.addUserToViewListOfDiscussionThread(user, discussionThread);
	}

	/**
	 * @author Vasu Sharma
	 * @since 04 October 2018
	 * @param DiscussionThreadCategory discussionThreadCategory : save this discussion thread category in db
	 */
	@Transactional
	@Override
	public void createDiscussionThreadCategory(DiscussionThreadCategory discussionThreadCategory) {
		discussionForumDao.createDiscussionThreadCategory(discussionThreadCategory);
	}

	/**
	 * @author Vasu Sharma
	 * @since 04 October 2018
	 * @param DiscussionThreadCategory discussionThreadCategory : update this discussion thread category in db
	 */
	@Transactional
	@Override
	public void updateDiscussionThreadCategory(DiscussionThreadCategory discussionThreadCategory) {
		discussionForumDao.updateDiscussionThreadCategory(discussionThreadCategory);
	}
	

	//======================================================================================
	
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 * Fetching all data for the approval
	 * @return List of the DiscussionPost
	 */
	@Transactional(readOnly=true)
	@Override
	public List<DiscussionPost> viewAll() {
		return discussionForumDao.viewAll();
	}

	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 * Update the data of the DiscussionPost table after updating the status
	 * Setting the current time of the updated records
	 * @param List of the DiscussionPost
	 */
	@Transactional(readOnly=false)
	@Override
	public void updatePostStatus(List<DiscussionPost> discussionPostList) {
		for(DiscussionPost discussionPost: discussionPostList)
		{
			if(discussionPost.getStatus() != null && !discussionPost.getStatus().equalsIgnoreCase(""))
			{
				discussionPost.setStatusTime(new Date(System.currentTimeMillis()));
			}
		}
		discussionForumDao.updatePostStatus(discussionPostList);
	}

	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 * @return DiscussionThread category type
	 * fetching the records of DiscussionThreadCategory by the category Name.
	 * @param CategoryName from the path variable
	 */
	@Transactional(readOnly=true)
	@Override
	public DiscussionThreadCategory fetchByCategoryName(String categoryName) {
		try{
			return discussionForumDao.fetchByCategoryName(categoryName);
		}catch (NoResultException e) {
			return null;
		}
	}
	
	/**
	 * @author Ajita Mittal
	 * @since 09-oct-2018
	 * @param updated Discussion Thread
	 * Sending the updated data to the database
	 */
	@Override
	@Transactional(readOnly=false)
	public void updateThread(DiscussionThread discussionThread)  {
		discussionForumDao.updateThread(discussionThread);
		
	}
	
	/**
	 * @author Ajita Mittal
	 * @since 23 November 2018
	 * @param Request Parameter - searchString (String)
	 * @return It will return the prepared list of discussion threads according to the searched parameter for view.
	 */
	@Transactional(readOnly=true)
	@Override
	public List<DiscussionForumThreadListView> searchDiscussionThreads(String searchString) 
	{
		List<DiscussionForumThreadListView> discussionForumThreadListView = new ArrayList<>();
		for(DiscussionThread discussionThread: discussionForumDao.searchDiscussionThreads(searchString))
		{
			List<DiscussionPost> totalApprovedPost = this.getApprovedDeletedPostsOfThread(discussionThread, 0, 0);
			DiscussionPost lastPost = null;
			int totalNoOfApprovedPost = totalApprovedPost.size();
			if(totalApprovedPost != null && !totalApprovedPost.isEmpty())
				lastPost = totalApprovedPost.get(totalApprovedPost.size()-1);
			discussionForumThreadListView.add(new DiscussionForumThreadListView(discussionThread, lastPost, totalNoOfApprovedPost));
		}
		return discussionForumThreadListView;
		
	}
	
}
