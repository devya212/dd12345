package com.nucleus.loggingaspect;

import java.util.Arrays;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * @author Mukesh Dewangan
 * @since 5 december 2018
 * This Class is the aspect class. This method will help us to log all the details of the method starting point and ending point and all of its arguments.
 */
@Aspect
@Component
public class LoggingAspect
{
	@Around("execution(* com.nucleus.*.*.*(..))")
	public Object logAround(ProceedingJoinPoint proceedingJoinPoint)
	{
		final Logger logger = Logger.getLogger(proceedingJoinPoint.getTarget().getClass());
		logger.info("************************************************");
		logger.info("Method "+proceedingJoinPoint.getSignature().getName()+" : started.");
		logger.info("Method name: "+proceedingJoinPoint.getSignature().getName());
		logger.info("Method arguments: "+Arrays.toString(proceedingJoinPoint.getArgs()));
		Object returnedObject = null;
		try
		{
			returnedObject = proceedingJoinPoint.proceed();
		}
		catch(Throwable throwableError)
		{
			logger.info("Exception: "+throwableError);
		}
		logger.info("Method "+proceedingJoinPoint.getSignature().getName()+" : ended.");
		logger.info("************************************************");
		return returnedObject;
	}
}
