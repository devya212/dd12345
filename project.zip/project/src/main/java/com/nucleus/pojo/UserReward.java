package com.nucleus.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "PFinnUserReward_testingmd")

public class UserReward {
	@Id
	@Column(length = 10)
	private long userId;
	@NotNull
	@Column(length = 20)
	@Length(max = 20)
	private String badge;
	@Column(length = 30)
	private int availablePoints;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getBadge() {
		return badge;
	}

	public void setBatch(String badge) {
		this.badge = badge;
	}

	public int getAvailablePoints() {
		return availablePoints;
	}

	public void setAvailablePoints(int availablePoints) {
		this.availablePoints = availablePoints;
	}

}
