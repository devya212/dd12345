package com.nucleus.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @author Vasu Sharma
 * @since 24 September 2018
 */

@Entity
@Table(name="PFinnDiscussionThreadCategory_temp1_testingmd")
@SequenceGenerator(name="pfinnDiscussionThreadCategorySequenceGenerator" , sequenceName="pfinnDiscussionThreadCategorySequenceGenerator" ,initialValue=1)

public class DiscussionThreadCategory {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="pfinnDiscussionThreadCategorySequenceGenerator")
	private int categoryId;
	@NotNull
	@Column(unique=true)
	@Size(min=1)
	private String categoryName;
//	@Type(type="text")
	private String categoryDescription;
	@OneToOne
	private DiscussionThreadCategory parentCategory;
	private String categoryBackgroundColor;
	
	//constructors
	public DiscussionThreadCategory() {
		super();
	}

	public DiscussionThreadCategory(int categoryId, String categoryName, String categoryDescription,
			DiscussionThreadCategory parentCategory, String categoryBackgroundColor) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.categoryDescription = categoryDescription;
		this.parentCategory = parentCategory;
		this.categoryBackgroundColor = categoryBackgroundColor;
	}

	//getters and setters
	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDescription() {
		return categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public DiscussionThreadCategory getParentCategory() {
		return parentCategory;
	}

	public void setParentCategory(DiscussionThreadCategory parentCategory) {
		this.parentCategory = parentCategory;
	}

	public String getCategoryBackgroundColor() {
		return categoryBackgroundColor;
	}

	public void setCategoryBackgroundColor(String categoryBackgroundColor) {
		this.categoryBackgroundColor = categoryBackgroundColor;
	}

	@Override
	public String toString() {
		return "DiscussionThreadCategory [categoryId=" + categoryId + ", categoryName=" + categoryName
				+ ", categoryDescription=" + categoryDescription + ", parentCategory=" + parentCategory
				+ ", categoryBackgroundColor=" + categoryBackgroundColor + "]";
	}
	
	
	
}
