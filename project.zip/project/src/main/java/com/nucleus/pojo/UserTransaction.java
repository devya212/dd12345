package com.nucleus.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "PFinnUserTransaction_testingmd")
@SequenceGenerator(name = "PTransactionSequence", sequenceName = "PTransactionSequence", initialValue = 1)
public class UserTransaction {
	@Id
	@GeneratedValue(generator = "PTransactionSequence", strategy = GenerationType.SEQUENCE)
	@Column(length = 10)
	private int transactionId;
	@NotNull
	@Column(length = 10)
	private long userId;
	@NotNull
	@Column(length = 10)
	private int eventId;
	@NotNull
	@Column(length = 10)
	private String transactionType;
	@NotNull
	@Column(length = 20)
	private int amount;
	@NotNull
	private String transactionDate;
	@Column(length = 30)
	private String eventType;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

}
