package com.nucleus.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "PFinnEventMaster_testingmd")
@SequenceGenerator(name="pfinnEventMasterSequenceGenerator" , sequenceName="pfinnEventMasterSequenceGenerator" ,initialValue=1)

public class EventMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="pfinnEventMasterSequenceGenerator")
	private int serial;
	@NotNull
	@Column(length = 20)
	@Length(max = 20)
	private String eventType;
	@NotNull
	@Column(length = 20)
	@Length(max = 20)
	private String eventFullName;
	@NotNull
	@Column(length = 20)
	@Length(max = 20)
	private String rating;
	@NotEmpty
	@Column(length = 20)
	@Length(max = 20)
	private int rewardPoints;

	public int getSerial() {
		return serial;
	}

	public void setSerial(int serial) {
		this.serial = serial;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public int getRewardPoints() {
		return rewardPoints;
	}

	public void setRewardPoints(int rewardPoints) {
		this.rewardPoints = rewardPoints;
	}

	public String getEventFullName() {
		return eventFullName;
	}

	public void setEventFullName(String eventFullName) {
		this.eventFullName = eventFullName;
	}

}
