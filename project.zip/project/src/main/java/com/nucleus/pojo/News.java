package com.nucleus.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author Vishal Talwar and Abhishek Sharma and Deepak Sharma
 * @since September 2018
 */
@Entity
@Table(name = "productPortalNews_testingmd")
@SequenceGenerator(name="pfinnproductPortalNewsSequenceGenerator" , sequenceName="pfinnproductPortalNewsSequenceGenerator" ,initialValue=1)

public class News {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator="pfinnproductPortalNewsSequenceGenerator")
	private int newsid;

	@Column(length = 4000)
	private String headline;

	@Column(length = 4000)
	private String content;
	@Column(columnDefinition = "CLOB")
	private String newsImage;

	private Date dateadded;
	private String status;
	@Column(columnDefinition = "BLOB")
	private byte[] pdffile;

	public byte[] getPdffile() {
		return pdffile;
	}

	public void setPdffile(byte[] pdffile) {
		this.pdffile = pdffile;
	}

	public int getNewsid() {
		return newsid;
	}

	public void setNewsid(int newsid) {
		this.newsid = newsid;
	}

	public Date getDateadded() {
		return dateadded;
	}

	public void setDateadded(Date dateadded) {
		this.dateadded = dateadded;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getNewsImage() {
		return newsImage;
	}

	public void setNewsImage(String newsImage) {
		this.newsImage = newsImage;
	}

}