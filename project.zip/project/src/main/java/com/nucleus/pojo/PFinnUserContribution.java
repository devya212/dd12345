package com.nucleus.pojo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PFinnUserContribution_testingmd")
@SequenceGenerator(name="pFinnUserContributionSequenceGenerator" , sequenceName="pFinnUserContributionSequenceGenerator" ,initialValue=1)

public class PFinnUserContribution {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator="pFinnUserContributionSequenceGenerator")
	private int eventId;
	private String description;
	private String eventType;
	private Date eventDate;
	private String status;
	private String rating;
	private String remark;
	private Date statusDate;
	@ManyToOne
	@JoinColumn(name = "userId")
	private PFinnNewUser pFinnNewUser;

	public PFinnUserContribution() {
		super();
	}

	public PFinnUserContribution(int eventId, String description, String eventType, Date eventDate, String status,
			String rating, String remark, Date statusDate, PFinnNewUser pFinnNewUser) {
		super();
		this.eventId = eventId;
		this.description = description;
		this.eventType = eventType;
		this.eventDate = eventDate;
		this.status = status;
		this.rating = rating;
		this.remark = remark;
		this.statusDate = statusDate;
		this.pFinnNewUser = pFinnNewUser;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public Date getEventDate() {
		return eventDate;
	}

	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	public PFinnNewUser getpFinnNewUser() {
		return pFinnNewUser;
	}

	public void setpFinnNewUser(PFinnNewUser pFinnNewUser) {
		this.pFinnNewUser = pFinnNewUser;
	}

	@Override
	public String toString() {
		return "PFinnUserContribution [eventId=" + eventId + ", description=" + description + ", eventType=" + eventType
				+ ", eventDate=" + eventDate + ", status=" + status + ", rating=" + rating + ", remark=" + remark
				+ ", statusDate=" + statusDate + ", pFinnNewUser=" + pFinnNewUser + "]";
	}

}
