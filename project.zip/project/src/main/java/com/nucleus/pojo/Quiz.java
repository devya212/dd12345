package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author Vishal Talwar
 * @since October 2018
 */
@Entity()
@Table(name = "pfinnquiz_testingmd")
@SequenceGenerator(name="pfinnquizSequenceGenerator" , sequenceName="pfinnquizSequenceGenerator" ,initialValue=1)

public class Quiz {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator="pfinnquizSequenceGenerator")
	private int questionid;
	@NotEmpty(message = "Question cannot be Empty")
	private String question;
	@NotEmpty(message = "Option cannot be Empty")
	private String optiona;
	@NotEmpty(message = "Option cannot be Empty")
	private String optionb;
	@NotEmpty(message = "Option cannot be Empty")
	private String optionc;
	@NotEmpty(message = "Option cannot be Empty")
	private String optiond;
	@NotEmpty(message = "Correct Answer cannot be Empty")
	private String correctanswer;
	
	private String category;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getQuestionid() {
		return questionid;
	}

	public void setQuestionid(int questionid) {
		this.questionid = questionid;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getOptiona() {
		return optiona;
	}

	public void setOptiona(String optiona) {
		this.optiona = optiona;
	}

	public String getOptionb() {
		return optionb;
	}

	public void setOptionb(String optionb) {
		this.optionb = optionb;
	}

	public String getOptionc() {
		return optionc;
	}

	public void setOptionc(String optionc) {
		this.optionc = optionc;
	}

	public String getOptiond() {
		return optiond;
	}

	public void setOptiond(String optiond) {
		this.optiond = optiond;
	}

	public String getCorrectanswer() {
		return correctanswer;
	}

	public void setCorrectanswer(String correctanswer) {
		this.correctanswer = correctanswer;
	}

}