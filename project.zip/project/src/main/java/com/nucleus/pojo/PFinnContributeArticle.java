package com.nucleus.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author Vasu Sharma
 * @since 20 September 2018
 */

@Entity
@Table(name = "PFinnContributeArticle_testingmd")
@SequenceGenerator(name="pFinnContributeArticlerSequenceGenerator" , sequenceName="pFinnContributeArticlerSequenceGenerator" ,initialValue=1)

public class PFinnContributeArticle {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="pFinnContributeArticlerSequenceGenerator")
	private int upload_id;

	@Column(columnDefinition = "BLOB")
	private byte[] file_data;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private PFinnNewUser pFinnNewUser;

	private Date upload_date;
	
	private String articleTitle;
	
	private String articleDescription;
	
	private String status;
	
	private Date statusDate;
	
	private String remark;
	

	public int getUpload_id() {
		return upload_id;
	}

	public void setUpload_id(int upload_id) {
		this.upload_id = upload_id;
	}

	public byte[] getFile_data() {
		return file_data;
	}

	public void setFile_data(byte[] file_data) {
		this.file_data = file_data;
	}

	public PFinnNewUser getpFinnNewUser() {
		return pFinnNewUser;
	}

	public void setpFinnNewUser(PFinnNewUser pFinnNewUser) {
		this.pFinnNewUser = pFinnNewUser;
	}

	public Date getUpload_date() {
		return upload_date;
	}

	public void setUpload_date(Date upload_date) {
		this.upload_date = upload_date;
	}

	public String getArticleTitle() {
		return articleTitle;
	}

	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}

	public String getArticleDescription() {
		return articleDescription;
	}

	public void setArticleDescription(String articleDescription) {
		this.articleDescription = articleDescription;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getStatusDate() {
		return statusDate;
	}

	public void setStatusDate(Date statusDate) {
		this.statusDate = statusDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "PFinnContributeArticle [upload_id=" + upload_id 
				+ ", pFinnNewUser=" + pFinnNewUser + ", upload_date=" + upload_date + ", articleTitle=" + articleTitle
				+ ", articleDescription=" + articleDescription + ", status=" + status + ", statusDate=" + statusDate
				+ ", remark=" + remark + "]";
	}

}
