package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author Vishal Talwar
 * @since September 2018
 */
@Entity
@Table(name = "pfinnrole_testingmd")
@SequenceGenerator(name="pfinnroleSequenceGenerator" , sequenceName="pfinnroleSequenceGenerator" ,initialValue=1)

public class PFinnRole {
	@Id
	@GeneratedValue(generator="pfinnroleSequenceGenerator" , strategy=GenerationType.SEQUENCE)
	private int roleId;
	private String roleName;

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

}
