package com.nucleus.pojo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @author Ajita Mittal
 * @since 24 September 2018
 */

@Entity
@Table(name="pfinnDiscussionPost_temp1_testingmd")
@SequenceGenerator(name="pfinnDiscussionPostSequenceGenerator" , sequenceName="pfinnDiscussionPostSequenceGenerator" , initialValue=1)
public class DiscussionPost
{
	@Id@GeneratedValue(strategy=GenerationType.SEQUENCE , generator="pfinnDiscussionPostSequenceGenerator")
	private int discussionPostId;
	@NotNull
	@Size(min=1)
//	@Type(type="text")
	private String postContent;
	@NotNull
	@ManyToOne
	private PFinnNewUser postedByUser;
	@NotNull
	@ManyToOne
	private DiscussionThread discussionThread;
	@NotNull
	private Date postedDate;
	private String status;
	private Date statusTime;
	@OneToOne
	private DiscussionPost quotedDiscussionPost;
	private String remarkForStatus;
	
	//constructors
	public DiscussionPost()
	{
		
	}
	
	

	public DiscussionPost(int discussionPostId, String postContent, PFinnNewUser postedByUser,
			DiscussionThread discussionThread, Date postedDate, String status, Date statusTime,
			DiscussionPost quotedDiscussionPost, String remarkForStatus) {
		super();
		this.discussionPostId = discussionPostId;
		this.postContent = postContent;
		this.postedByUser = postedByUser;
		this.discussionThread = discussionThread;
		this.postedDate = postedDate;
		this.status = status;
		this.statusTime = statusTime;
		this.quotedDiscussionPost = quotedDiscussionPost;
		this.remarkForStatus = remarkForStatus;
	}


	//getters and setters

	public int getDiscussionPostId() {
		return discussionPostId;
	}



	public void setDiscussionPostId(int discussionPostId) {
		this.discussionPostId = discussionPostId;
	}



	public String getPostContent() {
		return postContent;
	}



	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}



	public PFinnNewUser getPostedByUser() {
		return postedByUser;
	}



	public void setPostedByUser(PFinnNewUser postedByUser) {
		this.postedByUser = postedByUser;
	}



	public DiscussionThread getDiscussionThread() {
		return discussionThread;
	}



	public void setDiscussionThread(DiscussionThread discussionThread) {
		this.discussionThread = discussionThread;
	}



	public Date getPostedDate() {
		return postedDate;
	}



	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public Date getStatusTime() {
		return statusTime;
	}



	public void setStatusTime(Date statusTime) {
		this.statusTime = statusTime;
	}



	public DiscussionPost getQuotedDiscussionPost() {
		return quotedDiscussionPost;
	}



	public void setQuotedDiscussionPost(DiscussionPost quotedDiscussionPost) {
		this.quotedDiscussionPost = quotedDiscussionPost;
	}



	public String getRemarkForStatus() {
		return remarkForStatus;
	}



	public void setRemarkForStatus(String remarkForStatus) {
		this.remarkForStatus = remarkForStatus;
	}



	@Override
	public String toString() {
		return "DiscussionPost [discussionPostId=" + discussionPostId + ", postContent=" + postContent
				+ ", postedByUser=" + postedByUser + ", discussionThread=" + discussionThread + ", postedDate="
				+ postedDate + ", status=" + status + ", statusTime=" + statusTime + ", quotedDiscussionPost="
				+ quotedDiscussionPost + ", remarkForStatus=" + remarkForStatus + "]";
	}	
	
	
}
