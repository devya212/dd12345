package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author Vishal Talwar
 * @since October 2018
 */
@Entity
@Table(name = "portalQuizCheck_testingmd")
@SequenceGenerator(name="portalQuizCheckSequenceGenerator" , sequenceName="portalQuizCheckSequenceGenerator" ,initialValue=1)

public class QuizCheck {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator="portalQuizCheckSequenceGenerator")
	private int quizCheckId;
	private String userName;
	private int quizQuestionId;

	private String correctAnswer;

	public int getQuizCheckId() {
		return quizCheckId;
	}

	public void setQuizCheckId(int quizCheckId) {
		this.quizCheckId = quizCheckId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getQuizQuestionId() {
		return quizQuestionId;
	}

	public void setQuizQuestionId(int quizQuestionId) {
		this.quizQuestionId = quizQuestionId;
	}

	@Override
	public String toString() {
		return "QuizCheck [quizCheckId=" + quizCheckId + ", userName=" + userName + ", quizQuestionId=" + quizQuestionId
				+ ", correctAnswer=" + correctAnswer + "]";
	}

	public String getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

}
