insert into PFinnEventMaster values(1,'SUGGESTION','SIMPLE',10);
insert into PFinnEventMaster values(2,'SUGGESTION','MODERATE',20);
insert into PFinnEventMaster values(3,'SUGGESTION','COMPLEX',30);
insert into PFinnEventMaster values(4,'FEEDBACK','SIMPLE',10);
insert into PFinnEventMaster values(5,'FEEDBACK','MODERATE',20);
insert into PFinnEventMaster values(6,'FEEDBACK','COMPLEX',30);
insert into PFinnEventMaster values(4,'NEW IDEA','SIMPLE',10);
insert into PFinnEventMaster values(5,'NEW IDEA','MODERATE',20);
insert into PFinnEventMaster values(6,'NEW IDEA','COMPLEX',30);
desc PEventMaster;
select * from PFinnEventMaster;
commit;

select * from PFinnUserReward;

select * from PFinnUserTransaction;
select * from pfinnUserContribution;
delete from PFinnUserTransaction;
desc pfinnUserContribution;

rollback;

insert into pfinnUserContribution values(102,40,'Lets','SUGGESTION',sysdate,'A','MODERATE','none');
delete from PFinnUserTransaction;

select sysdate dt from dual;

alter session set nls_date_format='dd/mm/yyyy hh:mi:ss pm';

select sysdate dt from dual;